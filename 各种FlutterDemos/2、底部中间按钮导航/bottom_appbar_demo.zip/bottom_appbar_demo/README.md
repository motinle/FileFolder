# bottom_appbar_demo

## 简介
使用bottomAppbar进行底部导航，并居中浮动按钮的demo
## 样例1
![](../../../image/bottom_app_bar.png)

## 样例2

![bottom_app_bar2](../../../image/bottom_app_bar2.png)

## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).